// shared code
Websites = new Mongo.Collection("websites");
Comments = new Mongo.Collection("comments");
