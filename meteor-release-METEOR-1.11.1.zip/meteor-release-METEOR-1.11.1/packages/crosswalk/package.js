Package.describe({
  summary: "Makes your Cordova application use the Crosswalk WebView \
instead of the System WebView on Android",
  version: '1.7.1',
  documentation: null
});

Cordova.depends({
  'cordova-plugin-crosswalk-webview': '2.3.0'
});
