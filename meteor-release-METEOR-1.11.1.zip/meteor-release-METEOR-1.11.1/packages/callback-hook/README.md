# callback-hook
[Source code of released version](https://github.com/meteor/meteor/tree/master/packages/callback-hook) | [Source code of development version](https://github.com/meteor/meteor/tree/devel/packages/callback-hook)
***

This is an internal Meteor package.