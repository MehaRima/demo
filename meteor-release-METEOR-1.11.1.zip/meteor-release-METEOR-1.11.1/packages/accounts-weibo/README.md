# accounts-weibo
[Source code of released version](https://github.com/meteor/meteor/tree/master/packages/accounts-weibo) | [Source code of development version](https://github.com/meteor/meteor/tree/devel/packages/accounts-weibo)
***

A login service for Weibo. See the [project page](https://www.meteor.com/accounts) on Meteor Accounts for more details.