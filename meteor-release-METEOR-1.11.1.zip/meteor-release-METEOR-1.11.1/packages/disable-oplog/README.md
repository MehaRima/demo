# disable-oplog
[Source code of released version](https://github.com/meteor/meteor/tree/master/packages/disable-oplog) | [Source code of development version](https://github.com/meteor/meteor/tree/devel/packages/disable-oplog)
***

This is an internal Meteor package.