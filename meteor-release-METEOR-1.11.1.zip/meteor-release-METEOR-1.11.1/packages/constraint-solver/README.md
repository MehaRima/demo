# constraint-solver
[Source code of released version](https://github.com/meteor/meteor/tree/master/packages/constraint-solver) | [Source code of development version](https://github.com/meteor/meteor/tree/devel/packages/constraint-solver)
***

Meteor Version Solver is an optimizing constraint solver for package
dependencies. It is used by the Meteor build tool (Isobuild) for apps,
packages and build plugins.

To learn more about Meteor Version Solver see the [project page on
meteor.com](https://www.meteor.com/version-solver)

