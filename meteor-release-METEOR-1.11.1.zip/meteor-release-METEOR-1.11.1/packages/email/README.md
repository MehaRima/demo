# email
[Source code of released version](https://github.com/meteor/meteor/tree/master/packages/email) | [Source code of development version](https://github.com/meteor/meteor/tree/devel/packages/email)
***

The `email` package allows sending email from a Meteor app.

To see how to use it, read the [`email` section](http://docs.meteor.com/#email) of the Meteor docs.