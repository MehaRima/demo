# ddp-common
[Source code of released version](https://github.com/meteor/meteor/tree/master/packages/ddp-common) | [Source code of development version](https://github.com/meteor/meteor/tree/devel/packages/ddp-common)
***

