exports.fetchURL = "/__meteor__/dynamic-import/fetch";
