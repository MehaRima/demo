Package.describe({
  summary: "(For prototyping only) Publish the entire database to all clients",
  version: '1.0.7'
});

// This package is empty; its presence is detected by several other packages
// (such as ddp-server and mongo) which check for the presence of
// Package.autopublish.
