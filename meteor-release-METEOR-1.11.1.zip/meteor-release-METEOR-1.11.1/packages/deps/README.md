# deps
[Source code of released version](https://github.com/meteor/meteor/tree/master/packages/deps) | [Source code of development version](https://github.com/meteor/meteor/tree/devel/packages/deps)
***

This is an internal Meteor package.