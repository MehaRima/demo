# jquery-waypoints
[Source code of released version](https://github.com/meteor/meteor/tree/master/packages/jquery-waypoints) | [Source code of development version](https://github.com/meteor/meteor/tree/devel/packages/jquery-waypoints)
***

This is a wrapper package for the JQuery Waypoints library. You can use it to add callbacks that fire when the user scrolls to certain elements on a page, for example to implement table of contents highlighting.

See the [JQuery Waypoints docs](http://imakewebthings.com/jquery-waypoints/) for more details.