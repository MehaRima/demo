console.warn(
  "The `weibo` package has been deprecated.\n" +
  "\n" +
  "To use the `Weibo` symbol, add the `weibo-oauth` package\n" +
  "and import from it.\n" +
  "\n" +
  "If you need the Blaze OAuth configuration UI, add\n" +
  "`weibo-config-ui` alongside `accounts-ui`."
);
