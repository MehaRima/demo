# weibo
[Source code of released version](https://github.com/meteor/meteor/tree/master/packages/weibo) | [Source code of development version](https://github.com/meteor/meteor/tree/devel/packages/weibo)
***

** Deprecated, use weibo-oauth instead**

An implementation of the Weibo OAuth flow. See the [project
page](https://www.meteor.com/accounts) on Meteor Accounts for more
details.
