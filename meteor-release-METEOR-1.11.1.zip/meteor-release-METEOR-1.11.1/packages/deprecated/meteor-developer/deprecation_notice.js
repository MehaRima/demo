console.warn(
  "The `meteor-developer` package has been deprecated.\n" +
  "\n" +
  "To use the `MeteorDeveloperAccounts` symbol, add the\n" +
  "`meteor-developer-oauth` package and import from it.\n" +
  "\n" +
  "If you need the Blaze OAuth configuration UI, add\n" +
  "`meteor-developer-config-ui` alongside `accounts-ui`."
);
