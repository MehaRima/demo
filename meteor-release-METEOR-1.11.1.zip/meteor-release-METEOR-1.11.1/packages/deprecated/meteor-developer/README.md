# meteor-developer
[Source code of released version](https://github.com/meteor/meteor/tree/master/packages/meteor-developer) | [Source code of development version](https://github.com/meteor/meteor/tree/devel/packages/meteor-developer)
***

**Deprecated, use meteor-developer-oauth instead.**

An implementation of the Meteor developer accounts OAuth flow. See the [project page](https://www.meteor.com/accounts) on Meteor Accounts for more details.
