// Define an object named module.exports. This will cause fastclick.js to put
// FastClick as a field on it, instead of in the global namespace.
// See also post.js.
module = {
  exports: {}
};
