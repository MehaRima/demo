console.log("The 'preserve-inputs' package is now unnecessary and deprecated.");
