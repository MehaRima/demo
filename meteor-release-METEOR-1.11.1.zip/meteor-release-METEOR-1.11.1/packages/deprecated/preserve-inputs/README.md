# preserve-inputs
[Source code of released version](https://github.com/meteor/meteor/tree/master/packages/preserve-inputs) | [Source code of development version](https://github.com/meteor/meteor/tree/devel/packages/preserve-inputs)
***

This is an internal Meteor package.