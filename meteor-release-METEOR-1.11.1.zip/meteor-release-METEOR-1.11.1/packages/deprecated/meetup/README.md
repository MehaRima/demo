# meetup
[Source code of released version](https://github.com/meteor/meteor/tree/master/packages/meetup) | [Source code of development version](https://github.com/meteor/meteor/tree/devel/packages/meetup)
***

**Deprecated, use meetup-oauth instead.**

An implementation of the Meetup OAuth flow. See the [project page](https://www.meteor.com/accounts) on Meteor Accounts for more details.
