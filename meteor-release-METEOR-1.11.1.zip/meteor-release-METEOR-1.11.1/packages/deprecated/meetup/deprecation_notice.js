console.warn(
  "The `meetup` package has been deprecated.\n" +
  "\n" +
  "To use the `Meetup` symbol, add the `meetup-oauth` package\n" +
  "and import from it.\n" +
  "\n" +
  "If you need the Blaze OAuth configuration UI, add\n" +
  "`meetup-config-ui` alongside `accounts-ui`."
);
