# startup
[Source code of released version](https://github.com/meteor/meteor/tree/master/packages/startup) | [Source code of development version](https://github.com/meteor/meteor/tree/devel/packages/startup)
***

This is an internal Meteor package.