console.warn([
  "The `stylus` package has been deprecated.",
  "",
  "To continue using the last supported version",
  "of this package, pin your package version to",
  "2.513.13 (`meteor add stylus@=2.513.13`).",
].join("\n"));
