# github
[Source code of released version](https://github.com/meteor/meteor/tree/master/packages/github) | [Source code of development version](https://github.com/meteor/meteor/tree/devel/packages/github)
***

**Deprecated, use github-oauth instead.**

An implementation of the GitHub OAuth flow. See the [project page](https://www.meteor.com/accounts) on Meteor Accounts for more details.
