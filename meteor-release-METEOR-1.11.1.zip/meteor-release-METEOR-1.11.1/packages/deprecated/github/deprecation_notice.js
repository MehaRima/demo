console.warn(
  "The `github` package has been deprecated.\n" +
  "\n" +
  "To use the `Github` symbol, add the `github-oauth` package\n" +
  "and import from it.\n" +
  "\n" +
  "If you need the Blaze OAuth configuration UI, add\n" +
  "`github-config-ui` alongside `accounts-ui`."
);
