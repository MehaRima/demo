# standard-app-packages
[Source code of released version](https://github.com/meteor/meteor/tree/master/packages/standard-app-packages) | [Source code of development version](https://github.com/meteor/meteor/tree/devel/packages/standard-app-packages)
***

This is an internal Meteor package.