# twitter
[Source code of released version](https://github.com/meteor/meteor/tree/master/packages/twitter) | [Source code of development version](https://github.com/meteor/meteor/tree/devel/packages/twitter)
***

** Deprecated, use twitter-oauth instead**

An implementation of the Twitter OAuth flow. See the [project
page](https://www.meteor.com/accounts) on Meteor Accounts for more
details.
