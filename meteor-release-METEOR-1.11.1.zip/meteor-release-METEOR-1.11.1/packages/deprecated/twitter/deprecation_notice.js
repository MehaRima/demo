console.warn(
  "The `twitter` package has been deprecated.\n" +
  "\n" +
  "To use the `Twitter` symbol, add the `twitter-oauth` package\n" +
  "and import from it.\n" +
  "\n" +
  "If you need the Blaze OAuth configuration UI, add\n" +
  "`twitter-config-ui` alongside `accounts-ui`."
);
