# meteor-platform
[Source code of released version](https://github.com/meteor/meteor/tree/master/packages/meteor-platform) | [Source code of development version](https://github.com/meteor/meteor/tree/devel/packages/meteor-platform)
***

This package used to be added to every app by `meteor create`, but is now deprecated in favor of `meteor-base` and a carefully chosen set of other packages.

See the PR here with the discussion: https://github.com/meteor/meteor/pull/4851

This package was previously known as [standard-app-packages](https://atmospherejs.com/meteor/standard-app-packages).
