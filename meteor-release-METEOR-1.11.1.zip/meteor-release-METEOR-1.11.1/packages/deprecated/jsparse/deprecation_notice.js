console.warn(
  'The "jsparse" package is now unnecessary and has been deprecated.\n'
  + '\n'
  + 'To continue to use a working version of this package, please pin your\n'
  + 'package version to 1.0.10 (e.g. meteor add jsparse@=1.0.10).\n'
);
