# jsparse
[Source code of released version](https://github.com/meteor/meteor/tree/master/packages/jsparse) | [Source code of development version](https://github.com/meteor/meteor/tree/devel/packages/jsparse)
***

This internal Meteor package is now unnecessary and has been deprecated. To
continue to use a working version of this package, please pin your package
version to 1.0.10 (e.g. meteor add jsparse@=1.0.10)