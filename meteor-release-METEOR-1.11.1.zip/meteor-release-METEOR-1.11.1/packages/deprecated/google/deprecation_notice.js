console.warn(
  "The `google` package has been deprecated.\n" +
  "\n" +
  "To use the `Google` symbol, add the `google-oauth` package\n" +
  "and import from it.\n" +
  "\n" +
  "If you need the Blaze OAuth configuration UI, add\n" +
  "`google-config-ui` alongside `accounts-ui`."
);
