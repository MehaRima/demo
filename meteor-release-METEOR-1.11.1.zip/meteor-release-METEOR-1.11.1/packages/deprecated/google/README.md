# google-oauth
[Source code of released version](https://github.com/meteor/meteor/tree/master/packages/google) | [Source code of development version](https://github.com/meteor/meteor/tree/devel/packages/google)
***

** Deprecated, use google-oauth instead**

An implementation of the Google OAuth flow. See the [project page](https://www.meteor.com/accounts) on Meteor Accounts for more details. XXX link
