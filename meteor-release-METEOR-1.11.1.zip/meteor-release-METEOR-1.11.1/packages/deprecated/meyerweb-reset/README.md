# meyerweb-reset
[Source code of released version](https://github.com/meteor/meteor/tree/master/packages/meyerweb-reset) | [Source code of development version](https://github.com/meteor/meteor/tree/devel/packages/meyerweb-reset)
***

This internal Meteor package is now unnecessary and has been deprecated. To
continue to use a working version of this package, please pin your package
version to 1.0.7 (e.g. meteor add meyerweb-reset@=1.0.7)