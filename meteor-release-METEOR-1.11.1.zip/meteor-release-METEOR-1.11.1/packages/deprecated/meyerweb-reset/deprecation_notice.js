console.warn(
  'The "meyerweb-reset" package is now unnecessary and has been deprecated.\n',
  '\n',
  'To continue to use a working version of this package, please pin your\n',
   'package version to 1.0.7 (e.g. meteor add meyerweb-reset@=1.0.7).\n'
);
