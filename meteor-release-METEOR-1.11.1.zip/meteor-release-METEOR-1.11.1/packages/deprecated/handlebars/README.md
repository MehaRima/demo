# handlebars
[Source code of released version](https://github.com/meteor/meteor/tree/master/packages/handlebars) | [Source code of development version](https://github.com/meteor/meteor/tree/devel/packages/handlebars)
***

This is an internal Meteor package.