# facebook
[Source code of released version](https://github.com/meteor/meteor/tree/master/packages/facebook) | [Source code of development version](https://github.com/meteor/meteor/tree/devel/packages/facebook)
***

** Deprecated, use facebook-oauth instead**

An implementation of the Facebook OAuth flow. See the [project page](https://www.meteor.com/accounts) on Meteor Accounts for more details. XXX link
