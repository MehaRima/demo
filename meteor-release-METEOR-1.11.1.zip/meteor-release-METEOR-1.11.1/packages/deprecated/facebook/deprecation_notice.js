console.warn(
  "The `facebook` package has been deprecated.\n" +
  "\n" +
  "To use the `Facebook` symbol, add the `facebook-oauth` package\n" +
  "and import from it.\n" +
  "\n" +
  "If you need the Blaze OAuth configuration UI, add\n" +
  "`facebook-config-ui` alongside `accounts-ui`."
);
