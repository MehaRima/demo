# code-prettify
[Source code of released version](https://github.com/meteor/meteor/tree/master/packages/code-prettify) | [Source code of development version](https://github.com/meteor/meteor/tree/devel/packages/code-prettify)
***

This internal Meteor package is now unnecessary and has been deprecated. To
continue to use a working version of this package, please pin your package
version to 1.0.11 (e.g. meteor add code-prettify@=1.0.11). For details
concerning the deprecation of this package, see
[issue 4445](https://github.com/meteor/meteor/issues/4445).
