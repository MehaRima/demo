console.log(
  'The "code-prettify" package is now unnecessary and has been deprecated. '
  + 'To continue to use a working version of this package, please pin your '
  + 'package version to 1.0.11 (e.g. meteor add code-prettify@=1.0.11). '
  + 'For details concerning the deprecation of this package, see '
  + 'https://github.com/meteor/meteor/issues/4445.'
);
