# facts
[Source code of released version](https://github.com/meteor/meteor/tree/master/packages/facts) | [Source code of development version](https://github.com/meteor/meteor/tree/devel/packages/facts)
***

This is a legacy internal Meteor package. Use facts-ui or facts-base instead.
