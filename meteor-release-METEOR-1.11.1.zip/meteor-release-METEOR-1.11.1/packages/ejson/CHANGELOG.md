# CHANGELOG

## v1.1.1, 2019-12-20

* use map instead of object for list custom type
* add helpers based on native function to quick call in progress
* move helpers fn to utils file
* make the friendly error and add a test for this case (Fixes [Issue #10373](https://github.com/meteor/meteor/issues/10373))
thanks [Hieu Lam](https://github.com/lamhieu-vk)
