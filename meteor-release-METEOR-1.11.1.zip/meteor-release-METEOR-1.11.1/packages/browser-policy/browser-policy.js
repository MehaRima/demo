exports.BrowserPolicy = require("meteor/browser-policy-common").BrowserPolicy;
