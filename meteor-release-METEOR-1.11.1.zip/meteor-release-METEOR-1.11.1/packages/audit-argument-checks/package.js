Package.describe({
  summary: "Try to detect inadequate input sanitization",
  version: '1.0.7'
});

// This package is empty; its presence is detected by livedata.
