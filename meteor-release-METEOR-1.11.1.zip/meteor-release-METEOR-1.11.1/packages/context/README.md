# context
[Source code of released version](https://github.com/meteor/meteor/tree/master/packages/context) | [Source code of development version](https://github.com/meteor/meteor/tree/devel/packages/context)
***

Meteor wrapper package for the
[`@wry/context`](https://github.com/benjamn/wryware/tree/master/packages/context)
npm package.
