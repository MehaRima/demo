const { wrapYieldingFiberMethods } = require("@wry/context");
wrapYieldingFiberMethods(require("fibers"));
