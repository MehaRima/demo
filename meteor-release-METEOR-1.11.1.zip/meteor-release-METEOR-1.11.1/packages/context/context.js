const {
  Slot,
  bind,
  noContext,
  setTimeout,
  asyncFromGen,
} = require("@wry/context");

Object.assign(exports, {
  Slot,
  bind,
  noContext,
  setTimeout,
  asyncFromGen,
});
