# accounts-meetup
[Source code of released version](https://github.com/meteor/meteor/tree/master/packages/accounts-meetup) | [Source code of development version](https://github.com/meteor/meteor/tree/devel/packages/accounts-meetup)
***

A login service for Meetup. See the [project page](https://www.meteor.com/accounts) on Meteor Accounts for more details.