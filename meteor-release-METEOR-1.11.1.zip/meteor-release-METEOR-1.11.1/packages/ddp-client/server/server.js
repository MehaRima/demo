export { DDP } from '../common/namespace.js';
