export { DDP } from '../common/namespace.js';

import '../common/livedata_connection';

// Initialize the default server connection and put it on Meteor.connection
import './client_convenience';
