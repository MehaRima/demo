// Since this file is added with bare: true, this variable will be accessible
// in package scope.
var exportedFromBareFile = "Yes";
