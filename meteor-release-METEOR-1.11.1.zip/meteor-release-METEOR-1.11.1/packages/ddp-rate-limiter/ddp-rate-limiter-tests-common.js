// Common settings for DDPRateLimiter tests.
export const RATE_LIMIT_NUM_CALLS = 5;
export const RATE_LIMIT_INTERVAL_TIME_MS = 5000;
