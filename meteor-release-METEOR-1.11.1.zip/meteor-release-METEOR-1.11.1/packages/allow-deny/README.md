# allow-deny
[Source code of released version](https://github.com/meteor/meteor/tree/master/packages/allow-deny) | [Source code of development version](https://github.com/meteor/meteor/tree/devel/packages/allow-deny)
***

