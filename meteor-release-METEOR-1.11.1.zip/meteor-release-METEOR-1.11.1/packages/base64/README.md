# base64
[Source code of released version](https://github.com/meteor/meteor/tree/master/packages/base64) | [Source code of development version](https://github.com/meteor/meteor/tree/devel/packages/base64)
***

This is an internal Meteor package.