# CHANGELOG

## v1.2.3, 2019-12-13

* Rewrite appcache resources exceed recommended cache size debug message. Fixes [Issue #10321](https://github.com/meteor/meteor/issues/10321). Thanks [@CaptainN](https://github.com/CaptainN)
