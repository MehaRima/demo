# accounts-facebook
[Source code of released version](https://github.com/meteor/meteor/tree/master/packages/accounts-facebook) | [Source code of development version](https://github.com/meteor/meteor/tree/devel/packages/accounts-facebook)
***

A login service for Facebook. See the [project page](https://www.meteor.com/accounts) on Meteor Accounts for more details.